Program is written is C# using ASP.NET.

To run - place on IIS server, or IIS express, or WebMatrix, or load solution into visual studio and run from there. If you load into visual studio - you may need to change the project settings to look for a different local host then the one I used. Alternativey, you can "open a website" in visual studio and point it at the Assignment 5 directory, and it will open.

Required libraries:
ASP.NET 4

FOR THE XML
There is a hardcoded string for both the schema file and xml file.

Do a "find all and replace" on the entire solution on :

C:\\Users\\NikLubz\\SkyDrive\\Documents\\Third Year\\Web Technologies\\Assignment 5\\data.xml

and replace it with the location to your xml file.

Do a "fine all and replace" on the entire solution on: 

C:\\Users\\NikLubz\\SkyDrive\\Documents\\Third Year\\Web Technologies\\Assignment 5\\schema.xsd

and replace with the location of your schema file for validation.


any questions, email: nlubczyn@uwo.ca
